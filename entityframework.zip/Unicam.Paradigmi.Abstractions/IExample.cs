﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unicam.Paradigmi.Abstractions
{
    public interface IExample
    {
        void RunExample();
    }
}
