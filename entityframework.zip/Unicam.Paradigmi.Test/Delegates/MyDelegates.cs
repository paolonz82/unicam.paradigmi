﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unicam.Paradigmi.Test.Models;

namespace Unicam.Paradigmi.Test.Delegates
{
    public delegate void SottoScortaHandler(Articolo art,DateTime data);
}
